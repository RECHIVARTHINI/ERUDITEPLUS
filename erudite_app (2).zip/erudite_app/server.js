/*
const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Serve static files from the "public" folder
app.use(express.static('public'));

// Route the root (/) to dashboard.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

// Example search API (leave as-is)
app.get('/search', (req, res) => {
    const contentData = [
       "English Grade 6",
            "English Grade 7",
            "English Grade 8",
            "English Grade 9",
            "English Grade 10",
            "English Grade 11",
            "English Grade 12",
            "Botany Grade 11",
            "Botany Grade 12",
            "Zoology Grade 11",
            "Zoology Grade 12",
            "Chemistry Grade 11 volume 1",
            "Chemistry Grade 11 volume 2",
            "Chemistry Grade 12 volume 1",
            "Chemistry Grade 12 volume 2",
             "Physics Grade 11 volume 1",
            "Physics Grade 11 volume 2",
            "Physics Grade 12 volume 1",
            "Physics Grade 12 volume 2",
            "Science Grade 6",
            "Science Grade 7",
            "Science Grade 8",
            "Science Grade 9",
            "Science Grade 10", 
            "Maths Grade 6",
            "Maths Grade 7",
            "Maths Grade 8",
            "Maths Grade 9",
            "Maths Grade 10", 
            "Maths Grade 11",
            "Maths Grade 12",
             "History Grade 6",
             "Geography Grade 7",
             "Civics Grade 8",
             "Civics Grade 9",
             "Economics Grade 10"
    ];
    
    const query = req.query.query.toLowerCase();
    const results = contentData.filter(item =>
        item.toLowerCase().includes(query)
    );
    res.json({ results });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

*/
const express = require('express');
const app = express();
const PORT = 3000;

// Example book data (replace with your actual data)
const bookData = [
    { title: 'History Grade 6', grade: 'Grade 6', pdf: 'history_grade_6.pdf' },
    { title: 'Science Grade 6', grade: 'Grade 6', pdf: 'science_grade_6.pdf' },
    { title: 'Math Grade 7', grade: 'Grade 7', pdf: 'math_grade_7.pdf' },
    { title: 'Physics Grade 8', grade: 'Grade 8', pdf: 'physics_grade_8.pdf' },
    { title: 'Chemistry Grade 9', grade: 'Grade 9', pdf: 'chemistry_grade_9.pdf' },
    { title: 'Biology Grade 10', grade: 'Grade 10', pdf: 'biology_grade_10.pdf' },
    { title: 'Math Grade 11', grade: 'Grade 11', pdf: 'math_grade_11.pdf' },
    { title: 'English Grade 12', grade: 'Grade 12', pdf: 'english_grade_12.pdf' }
];

// Serve static files (like HTML, CSS, JS)
app.use(express.static('public'));

// Endpoint to get filtered books
app.get('/books', (req, res) => {
    const grade = req.query.grade || 'All'; // Get grade from query parameter
    let filteredBooks = bookData;

    // Filter by grade if not 'All'
    if (grade !== 'All') {
        filteredBooks = bookData.filter(book => book.grade === grade);
    }

    res.json(filteredBooks); // Send filtered books as a JSON response
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
